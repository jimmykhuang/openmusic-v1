# Perhatian
untuk menjalankan wajib di terminal<br />
npm install<br />
npm install pg<br />
npm install dotenv<br />
npm install node-pg-migrate<br />
npm run migrate create "create table Songs"<br />
npm run migrate up<br />
# jgn lupa .envnya di setting
HOST=localhost<br />
PORT=5000<br />
NODE_ENV=development<br />
PGUSER=postgres<br />
PGHOST=localhost<br />
PGPASSWORD=root
